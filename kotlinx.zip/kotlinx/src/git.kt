import kotlinx.coroutines.*

data class Contributor(val login: String, val repoCount: Int)

fun main() = runBlocking {
    println("GitHub Repository Loader (Coroutines Version)")
    println("Введите имя пользователя/организации GitHub: ")
    val username = readLine()
    println("Введите токен или пароль GitHub: ")
    val token = readLine()
    val selectedOption = "Блокировка"
    println("\n[Меню]: Выбран элемент $selectedOption")
    if (selectedOption == "Блокировка") {
        println("[Система]: Выбрана кнопка загрузки участников")
        val results = loadDataBlocking()
        println("\n---Результаты загрузки---")
        results.forEach { user ->
            println("Участник: ${user.login} | Репозиториев: ${user.repoCount}")
        }
    }
}

suspend fun loadDataBlocking(): List<Contributor> {
    println("\nЗаполните данные пяти пользователей в формате: name, кнопка [enter], count")
    val users = listOf(
        Contributor(readLine().toString(), readLine()!!.toInt()),
        Contributor(readLine().toString(), readLine()!!.toInt()),
        Contributor(readLine().toString(), readLine()!!.toInt()),
        Contributor(readLine().toString(), readLine()!!.toInt()),
        Contributor(readLine().toString(), readLine()!!.toInt())
    )
    println("Интерфейс грузит 4 секунды, идет обработка в основном потоке")
    Thread.sleep(4000)
    return users
}