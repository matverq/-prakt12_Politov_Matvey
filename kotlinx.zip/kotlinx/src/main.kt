import kotlinx.coroutines.*
import kotlin.random.Random

suspend fun fetchData(id:Int):String{
    val delayT= Random.nextLong(800,5000)
    delay(delayT)
    return "Результат $id заняло ${delayT} мс"
}
fun main()= runBlocking {
    println("Введите количество функций: ")
    val n= readLine()?.toIntOrNull()?:0
    println("Запуск $n корутин")
    val startTime=System.currentTimeMillis()
    val defResult=(1..n).map { id->
        async {
            fetchData(id)
        }
    }
    val results=defResult.awaitAll()
    val endTime=System.currentTimeMillis()
    results.forEach{ println(it) }
    println("Общее время выполнения: ${endTime-startTime} мс")
}